import mongoose from 'mongoose';

const jobSchema = new mongoose.Schema({
     title:{
        type:String,
        required:true
     },
     description:{
        type:String,
        required:true
     },
     requirements:[{  // i have changed array tell me how 
        type:String
     }],
     salary:{
        type:Number,
        required:true
     },
     experienceLevel:{
      type:String,
      required:true
     },
     location:{
        type:String,
        required:true
     },
     jobType:{
        type:String,
        required:true
     },
     position:{
        type:Number,
        required:true
    },
   //  company id refers to Company collection
    company:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'Company',
        required:true
    },
    created_by:{
        type:mongoose.Schema.Types.ObjectId,
        ref:'User',
        required:true
    },
    applications:[
        {
            type:mongoose.Schema.Types.ObjectId,
            ref:'Application'
        }
    ]
},{timestamps:true});

export const Job = mongoose.model('Job',jobSchema);