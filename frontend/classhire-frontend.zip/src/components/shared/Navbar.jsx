import React from "react";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover.jsx";
import { Button } from "@/components/ui/button.jsx";
import { LogOut, User2 } from "lucide-react";
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "@/components/ui/avatar.jsx";
import { Link, NavLink, useNavigate } from "react-router-dom";
import { useDispatch, useSelector } from "react-redux";
import axios from "axios";
import { USER_API_END_POINT } from "@/utils/constant.js";
import { setUser } from "@/redux/authSlice.js";
import { toast } from "sonner";
import { ModeToggle } from "./mode-toggle.jsx";

const Navbar = () => {
  //make open profile section for recruiter also -

  const { user } = useSelector((store) => store.auth);

  const dispatch = useDispatch();

  const navigate = useNavigate();

  //below is just for logout and then redirect to home page , dispatch krke redux store mai user ko null krdo , aur phir / redirect kr do
  const logoutHandler = async () => {
    try {
      const res = await axios.get(`${USER_API_END_POINT}/logout`, {
        withCredentials: true,
      });
      if (res.data.success) {
        dispatch(setUser(null));
        navigate("/");
        toast.success(res.data.message);
      }
    } catch (error) {
      console.log(error);
      toast.error(error.response.data.message);
    }
  };

  return (
    <div className="bg-white">
      <div className="flex items-center justify-between mx-auto max-w-7xl h-16">
        <div>
          <h1 className="text-3xl font-bold text-[#384B70]">
            <Link to="/">
              Class<span className="text-[#384B70]">Hire</span>
            </Link>
          </h1>
        </div>
        <div className="flex items-center gap-5">
          <ul className="flex font-medium hover:text-[#384B70] items-center gap-5">
            {user && user.role === "recruiter" ? (
              <>
                <li>
                  <NavLink to="/admin/companies">
                    {({ isActive }) => (
                      <div
                        className={
                          isActive ? "bg-gray-200 px-3 py-1 rounded" : ""
                        }
                      >
                        Companies
                      </div>
                    )}
                  </NavLink>
                </li>
                <li>
                  <NavLink to="/admin/jobs">
                    {({ isActive }) => (
                      <div
                        className={
                          isActive ? "bg-gray-200 px-3 py-1 rounded" : ""
                        }
                      >
                        Jobs
                      </div>
                    )}
                  </NavLink>
                </li>
              </>
            ) : (
              <>
                <li>
                  <NavLink to="/">
                    {({ isActive }) => (
                      <div
                        className={
                          isActive ? "bg-gray-200 px-3 py-1 rounded" : ""
                        }
                      >
                        Home
                      </div>
                    )}
                  </NavLink>
                </li>
                <li>
                  <NavLink to="/jobs">
                    {({ isActive }) => (
                      <div
                        className={
                          isActive ? "bg-gray-200 px-3 py-1 rounded" : ""
                        }
                      >
                        Jobs
                      </div>
                    )}
                  </NavLink>
                </li>
                <li>
                  <NavLink to="/browse">
                    {({ isActive }) => (
                      <div
                        className={
                          isActive ? "bg-gray-200 px-3 py-1 rounded" : ""
                        }
                      >
                        Browse
                      </div>
                    )}
                  </NavLink>
                </li>
              </>
            )}
          </ul>
          {!user ? (
            <div className="flex items-center gap-2">
              <Link to="/login">
                <Button className="cursor-pointer" variant="outline">
                  Login
                </Button>
              </Link>
              <Link to="/signup">
                <Button className="bg-[#384B70] hover:bg-gray-700 cursor-pointer">
                  Sign Up
                </Button>
              </Link>
              <ModeToggle />
            </div>
          ) : (
            <Popover>
              <PopoverTrigger asChild>
                <Avatar className="cursor-pointer">
                  <AvatarImage src={user?.profile?.profilePhoto} />
                </Avatar>
              </PopoverTrigger>
              <PopoverContent className="w-64">
                <div className="flex gap-4 space-y-2">
                  <Avatar className="cursor-pointer">
                    <AvatarImage src={user?.profile?.profilePhoto} />
                  </Avatar>
                  <div>
                    <h4 className="font-medium">{user?.fullname}</h4>
                    <p className="text-sm text-muted-foreground">
                      {user?.profile?.bio}
                    </p>
                  </div>
                </div>
                <div className="flex flex-col my-2 text-gray-600">
                  {user && user.role === "student" && (
                    <div className="flex w-fit items-center gap-2 cursor-pointer">
                      <User2 />
                      <Button className="cursor-pointer" variant="link">
                        <Link to="/profile">View Profile</Link>
                      </Button>
                    </div>
                  )}

                  <div className="flex w-fit items-center gap-2 cursor-pointer">
                    <LogOut />
                    <Button
                      onClick={logoutHandler}
                      variant="link"
                      className="cursor-pointer"
                    >
                      Logout
                    </Button>
                  </div>
                </div>
              </PopoverContent>
            </Popover>
          )}
        </div>
      </div>
    </div>
  );
};

export default Navbar;
