import React from "react";
import { Button } from "../../../components/ui/button.jsx";
import { Bookmark } from "lucide-react";
import { Avatar, AvatarImage } from "../../../components/ui/avatar.jsx";
import { Badge } from "../../../components/ui/badge.jsx";
import { useNavigate } from "react-router-dom";
const Job = ({ job }) => {
  const navigate = useNavigate();
  // const jobId = "lshfdshfldshfls"

  const daysAgoFunction = (mongodbTime) => {
    const createdAt = new Date(mongodbTime);
    const currentTime = new Date();
    const timeDifference = currentTime - createdAt;
    return Math.floor(timeDifference / (1000 * 24 * 60 * 60));
  };
  return (
    <div className="p-5 rounded-md shadow-xl bg-white border border-gray-100">
      <div className="flex items-center justify-between">
        <p className="text-sm text-gray-500">
          {daysAgoFunction(job?.createdAt) === 0
            ? "Today"
            : `${daysAgoFunction(job?.createdAt)} days ago`}
        </p>
        <Button variant="outline" className="rounded-full" size="icon">
          <Bookmark />
        </Button>
      </div>

      <div className="flex items-center gap-2 my-2">
        {/* <Button className="p-6" variant="outline" size="icon">
          <Avatar>
            <AvatarImage src="https://www.shutterstock.com/image-vector/circle-line-simple-design-logo-600nw-2174926871.jpg"></AvatarImage>
          </Avatar>
        </Button> */}
        <div className="h-12 w-16 flex items-center justify-center border rounded-md bg-white overflow-hidden p-1">
          <img
            src={job?.company?.logo}
            alt={job?.company?.name}
            // className="max-h-8 max-w-[36px] object-contain"
            className="h-full w-full object-contain"
          />
        </div>
        <div>
          <h1 className="font-medium text-lg">{job?.company?.name}</h1>
          <p className="text-sm text-gray-500">India</p>
        </div>
      </div>
      <div>
        <h1 className="font-bold text-lg my-2">{job?.title}</h1>
        <p className="text-sm text-gray-600">{job?.description}</p>
      </div>
      <div className="flex items-center gap-2 mt-4">
        <Badge className={"text-[#384B70] font-bold"} variant="secondary">
          {job?.position}
        </Badge>
        <Badge className={"text-[#384B70] font-bold"} variant="secondary">
          {job?.jobType}
        </Badge>
        <Badge className={"text-[#384B70] font-bold"} variant="secondary">
          {job?.salary}
        </Badge>
      </div>
      <div className="flex items-center gap-4 mt-4">
        <Button
          onClick={() => navigate(`/description/${job?._id}`)}
          variant="outline"
        >
          Details
        </Button>
        <Button className="bg-[#384B70]">Save For Later</Button>
      </div>
    </div>
  );
};

export default Job;
